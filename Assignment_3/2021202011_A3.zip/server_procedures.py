def multiply(param1, param2):  # (int, int)
    print("Inside multiply func res: ", end="")
    print(param1 * param2)
    return (param1 * param2)

def addition(param1, param2): #(int, int)
    return (param1 + param2)

def foo(param1):  # (int)
    print("From function: ", end="")
    print(param1)
    return (param1)

def bar(param1, param2):  # (int, string)
    return (param1)

def voidFunc(param1):
    print("HelloWorld!!")

def univAdd(param1, param2):
    return (param1 + param2)

def boolOp(param1, param2):
    return (param1 or param2)

def noParam():
    print("This func has no parameters")
    return False

def noParamReturn():
    print("This func has no parameters and return type")
    return


def division(param1, param2):
    return (param1/param2)